/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Pause, 
  TrendingUp, 
  AlertCircle, 
  ExternalLink, 
  ShieldCheck, 
  Cpu, 
  Activity,
  Globe,
  ChevronRight,
  Volume2
} from 'lucide-react';

type PredictionType = 'ROSA' | 'AGUARDAR' | 'ALTA' | 'IDLE';

interface Site {
  name: string;
  url: string;
  color: string;
}

const SITES: Site[] = [
  { name: 'Kwanzabet', url: 'https://www.kwanzabet.ao/pt/casino/game-view/806666/aviator', color: 'bg-blue-600' },
  { name: 'Bantubet', url: 'https://m.bantubet.co.ao/pt/games/home', color: 'bg-yellow-600' },
  { name: 'ElephantBet', url: 'https://www.elephantbet.co.ao/pt/', color: 'bg-red-600' },
  { name: 'Ebet', url: 'https://ebet.co.ao/home', color: 'bg-green-600' },
];

export default function App() {
  const [isRunning, setIsRunning] = useState(false);
  const [prediction, setPrediction] = useState<PredictionType>('IDLE');
  const [multiplier, setMultiplier] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [currentSite, setCurrentSite] = useState<Site>(SITES[0]);
  const [scanProgress, setScanProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const addLog = (msg: string) => {
    setLogs(prev => [msg, ...prev].slice(0, 5));
  };

  const speak = (msg: string) => {
    const speech = new SpeechSynthesisUtterance(msg);
    speech.lang = "pt-PT";
    window.speechSynthesis.speak(speech);
  };

  const generatePrediction = useCallback(() => {
    setIsScanning(true);
    setScanProgress(0);
    addLog("Iniciando varredura de padrões...");

    let progress = 0;
    const progressInterval = setInterval(() => {
      progress += 5;
      setScanProgress(progress);
      if (progress >= 100) {
        clearInterval(progressInterval);
        
        const r = Math.random();
        let newPred: PredictionType;
        let newMult: string | null = null;
        
        if (r < 0.25) {
          newPred = 'ROSA';
          newMult = (Math.random() * (100 - 10) + 10).toFixed(2) + 'x';
          speak(`Entrar agora. Vela rosa detectada de ${newMult}`);
          addLog(`ALERTA: Padrão de Vela Rosa (${newMult}) identificado!`);
        } else if (r < 0.6) {
          newPred = 'AGUARDAR';
          addLog("Análise: Mercado instável. Aguardando.");
        } else {
          newPred = 'ALTA';
          newMult = (Math.random() * (9.99 - 2) + 2).toFixed(2) + 'x';
          addLog(`Análise: Vela alta (${newMult}) provável. Monitorando.`);
        }
        
        setMultiplier(newMult);
        setPrediction(newPred);
        setIsScanning(false);
      }
    }, 100);
  }, []);

  useEffect(() => {
    if (isRunning) {
      generatePrediction();
      intervalRef.current = setInterval(generatePrediction, 8000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setPrediction('IDLE');
      setIsScanning(false);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, generatePrediction]);

  const toggleAI = () => {
    setIsRunning(!isRunning);
    if (!isRunning) {
      addLog("Sistema YAW AI PRO+ inicializado.");
    } else {
      addLog("Sistema em standby.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-neon-cyan text-dark-bg py-3 px-6 flex items-center justify-between shadow-lg z-10">
        <div className="flex items-center gap-2">
          <Cpu className="w-6 h-6 animate-pulse" />
          <h1 className="font-bold text-xl tracking-tighter">YAW AI PRO+</h1>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono font-bold">
          <div className="flex items-center gap-1">
            <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-600 animate-ping' : 'bg-red-600'}`} />
            {isRunning ? 'SISTEMA ATIVO' : 'OFFLINE'}
          </div>
          <div className="hidden sm:block opacity-70">v4.2.0-STABLE</div>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Control & Prediction */}
        <div className="lg:col-span-4 space-y-6">
          {/* AI Control Card */}
          <section className="glass-panel p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-2 opacity-10">
              <Activity className="w-24 h-24" />
            </div>
            
            <h2 className="text-neon-cyan font-bold mb-4 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5" />
              PAINEL DE CONTROLE
            </h2>

            <button 
              onClick={toggleAI}
              className={`w-full py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-3 ${
                isRunning 
                ? 'bg-neon-pink text-white neon-glow-pink hover:bg-pink-600' 
                : 'bg-neon-cyan text-dark-bg neon-glow-cyan hover:bg-cyan-400'
              }`}
            >
              {isRunning ? <Pause className="fill-current" /> : <Play className="fill-current" />}
              {isRunning ? 'DESATIVAR IA' : 'INICIAR IA'}
            </button>

            <div className="mt-6 space-y-4">
              <div className="h-32 flex flex-col items-center justify-center border border-white/5 bg-black/20 rounded-xl">
                <AnimatePresence mode="wait">
                  {isScanning ? (
                    <motion.div 
                      key="scanning"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="w-full px-8 text-center"
                    >
                      <div className="text-xs font-mono text-neon-cyan mb-2">ANALISANDO MERCADO... {scanProgress}%</div>
                      <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                        <motion.div 
                          className="bg-neon-cyan h-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${scanProgress}%` }}
                        />
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div 
                      key={prediction}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-center"
                    >
                      {prediction === 'IDLE' && (
                        <div className="text-white/30 font-mono italic">Aguardando comando...</div>
                      )}
                      {prediction === 'ROSA' && (
                        <div className="space-y-1">
                          <div className="text-neon-pink font-black text-3xl tracking-tighter animate-bounce">VELA ROSA</div>
                          <div className="text-2xl font-mono font-bold text-white">{multiplier}</div>
                          <div className="text-xs text-white/60 font-mono">ENTRAR AGORA</div>
                        </div>
                      )}
                      {prediction === 'AGUARDAR' && (
                        <div className="space-y-1">
                          <div className="text-yellow-400 font-black text-3xl tracking-tighter">AGUARDAR</div>
                          <div className="text-xs text-white/60 font-mono">MERCADO INSTÁVEL</div>
                        </div>
                      )}
                      {prediction === 'ALTA' && (
                        <div className="space-y-1">
                          <div className="text-neon-cyan font-black text-3xl tracking-tighter">VELA ALTA</div>
                          <div className="text-xl font-mono font-bold text-white/80">{multiplier}</div>
                          <div className="text-xs text-white/60 font-mono">AGUARDAR CONFIRMAÇÃO</div>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button 
                onClick={() => alert("Entrada confirmada no sistema.")}
                disabled={prediction !== 'ROSA'}
                className={`w-full py-3 rounded-xl font-bold transition-all ${
                  prediction === 'ROSA' 
                  ? 'bg-neon-pink text-white animate-pulse' 
                  : 'bg-white/5 text-white/20 cursor-not-allowed'
                }`}
              >
                💰 ENTRAR AGORA
              </button>
            </div>
          </section>

          {/* Logs Card */}
          <section className="glass-panel p-4">
            <h3 className="text-xs font-mono text-white/40 mb-3 flex items-center gap-2">
              <Activity className="w-3 h-3" />
              LOGS DO SISTEMA
            </h3>
            <div className="space-y-2 font-mono text-[10px]">
              {logs.map((log, i) => (
                <div key={i} className="flex gap-2 border-l border-white/10 pl-2 py-1">
                  <span className="text-neon-cyan opacity-50">[{new Date().toLocaleTimeString()}]</span>
                  <span className="text-white/80">{log}</span>
                </div>
              ))}
              {logs.length === 0 && <div className="text-white/20 italic">Nenhuma atividade registrada.</div>}
            </div>
          </section>
        </div>

        {/* Right Column: Site Selection & Iframe */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Site Selector */}
          <section className="glass-panel p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-neon-cyan font-bold flex items-center gap-2">
                <Globe className="w-5 h-5" />
                PLATAFORMAS COMPATÍVEIS
              </h2>
              <Volume2 className="w-5 h-5 text-white/20 cursor-pointer hover:text-neon-cyan transition-colors" />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {SITES.map((site) => (
                <button
                  key={site.name}
                  onClick={() => setCurrentSite(site)}
                  className={`p-3 rounded-xl text-xs font-bold transition-all flex items-center justify-between group ${
                    currentSite.name === site.name 
                    ? 'bg-white/10 border-neon-cyan border shadow-[0_0_10px_rgba(0,255,213,0.2)]' 
                    : 'bg-white/5 border border-transparent hover:bg-white/10'
                  }`}
                >
                  {site.name}
                  <ChevronRight className={`w-3 h-3 transition-transform ${currentSite.name === site.name ? 'translate-x-1 text-neon-cyan' : 'opacity-0 group-hover:opacity-100'}`} />
                </button>
              ))}
            </div>
          </section>

          {/* Iframe View */}
          <section className="glass-panel flex-1 min-h-[500px] relative overflow-hidden flex flex-col">
            <div className="bg-black/40 px-4 py-2 flex items-center justify-between text-[10px] font-mono border-b border-white/5">
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  <div className="w-2 h-2 rounded-full bg-red-500/50" />
                  <div className="w-2 h-2 rounded-full bg-yellow-500/50" />
                  <div className="w-2 h-2 rounded-full bg-green-500/50" />
                </div>
                <span className="text-white/40 truncate max-w-[200px]">{currentSite.url}</span>
              </div>
              <a 
                href={currentSite.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-neon-cyan flex items-center gap-1 transition-colors"
              >
                ABRIR EXTERNO <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div className="flex-1 bg-black/20 relative">
              <iframe 
                src={currentSite.url} 
                className="w-full h-full border-none"
                title="Betting Platform"
              />
              {/* Overlay for "Iframe blocked" common issue */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-12 text-center opacity-20">
                <div className="space-y-2">
                  <TrendingUp className="w-12 h-12 mx-auto" />
                  <p className="text-xs">Se a plataforma não carregar, use o botão "ABRIR EXTERNO" acima.</p>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="p-4 text-center text-[10px] text-white/20 font-mono tracking-widest uppercase">
        © 2026 YAW AI PRO+ SYSTEMS • ENCRYPTED CONNECTION • SECURE ALGORITHM
      </footer>
    </div>
  );
}
